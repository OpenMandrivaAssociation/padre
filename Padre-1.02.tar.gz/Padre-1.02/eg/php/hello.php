<?php 
 Echo "Hello, World!";
 ?> 