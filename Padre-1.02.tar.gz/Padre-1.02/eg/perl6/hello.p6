
"Hello ".say;
"world".say;

