package Padre::Project::Perl::MI;

# Perl project driven by Module::Install

use 5.008005;
use strict;
use warnings;
use Padre::Project::Perl::EUMM ();

our $VERSION = '1.02';
our @ISA     = 'Padre::Project::Perl::EUMM';

1;


__END__

# Copyright 2008-2016 The Padre development team as listed in Padre.pm.
# LICENSE
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl 5 itself.

